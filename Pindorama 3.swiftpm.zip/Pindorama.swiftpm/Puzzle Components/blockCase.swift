//
//  blockCase.swift
//  
//
//  Created by Bof on 19/04/23.
//

import Foundation
import SwiftUI

enum blockCase {
    case wrong, right, bonus;
}
