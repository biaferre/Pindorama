import SwiftUI

struct PuzzleModel {
    var board: [[Int]] = [[1, 2, 3], [4,5,6], [7,8,9]]
    var angles: [[Double]] = [[0, 0, 0], [0,0,0], [0,0,0]]

    
}
